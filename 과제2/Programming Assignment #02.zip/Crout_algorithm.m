n=input('What is the dimension n? ');
A=zeros(n,n);b=zeros(n,1);l=eye(n);u=eye(n);
saveb=zeros(n,1);
saveA=zeros(n,n);
for j=1:n
    A(j,j)=2;
end
for j=1:n-1
    A(j,j+1)=-1;
    A(j+1,j)=-1;
end
b(1)=1;
saveA=A;
saveb=b;
l(:,1)=A(:,1);
u(1,:)=A(1,:)/l(1,1);
u(1,1)=1;
for k=2:n
for j=2:n
    for i=j:n
        l(i,j)=A(i,j)-dot(l(i,1:j-1),u(1:j-1,j));
    end
    u(k,j)=(A(k,j)-dot(l(k,1:k-1),u(1:k-1,j)))/l(k,k);
end
end
% decomposition Ȯ��
check=zeros(n,n);
count = 0;
for i = 1 : n
    for j = 1 : n
        check(i,j)=l(i,:)*u(:,j);
        if(abs(saveA(i,j) - check(i,j)) >5*10^-13)
            count = count + 1;
        end
    end
end
if(count ~= 0)
    disp("incorrect LU decomposition");
else
    disp("correct LU decomposition");
end
for j=1:n
    b(j)=(b(j)-dot(l(j,1:j-1),b(1:j-1)))/l(j,j); %forward substitution
end
for j=n:-1:1
    b(j)=(b(j)-dot(u(j,j+1:n),b(j+1:n)))/u(j,j); %backward substitution
end
for j=1:n
if(abs(saveb(j)-dot(saveA(j,1:n),b(1:n)))>5*10^-13)
    count=count+1;
end
end
if(count~=0)
    fprintf('The computed solution seems to be wrong at %f \n',j);
end
disp('The solution x is as follows: ')
disp(b)

    