A=input('LU���ظ� �˰� ���� ���簢����� �Է��Ͻÿ�: ');
b=input('A�� size�� ���߾� Ax=b �׸��� b�� �Է��Ͻÿ�: ');
[n,m]=size(A);
if(n~=m)
    disp('���簢����� �ƴմϴ�.');
    return;
end
Q=cell(1,n-1); %Permutation matrix Q1 Q2... Q(n-1)
saveA=A;saveb=b;x=zeros(n,1);count=0;
for j=1:n-1
    Q{j}=eye(n);
    [mx,js]=max(abs(A(j:n,j)));
    [mx,ks]=max(abs(A(j,j:n)));
    js=js+j-1;
    ks=ks+j-1;
    if (abs(A(js,j))>=abs(A(j,ks))) %row���� ū ���
        ks=j;
        A([j,js],:)=A([js,j],:);
        b([j,js])=b([js,j]);
    else %column�� ū ���
        js=j;
        A(:,[j,ks])=A(:,[ks,j]);
        Q{j}(:,[j,ks])=Q{j}(:,[ks,j]);
    end
    for i=j+1:n
        m=A(i,j)/A(j,j);
        A(i,j:n)=A(i,j:n)-m*A(j,j:n);
        b(i)=b(i)-m*b(j);
    end %Gauss elimination
end
disp("The result of LU decomposition is: ")
U=A
x(n,1)=b(n)/U(n,n); 
for i=n-1:-1:1
    x(i)=(b(i)-dot(U(i,i+1:n),x(i+1:n)))/U(i,i);
end
y=zeros(n,1); %temporary variable
for j=n-1:-1:1
    for k=1:n
        y(k)=Q{j}(k,:)*x;
    end
    x=y;
end
%solution �˻�
check1=zeros(n,1); check2=zeros(n,1);
for i=1:n
    check1(i,1)=saveA(i,:)*x;
    check2(i,1)=saveb(i);
end
for i=1:n
    if(abs(check1(i,1)-check2(i,1))>10^-13)
        count=count+1;
    end
end
if(count~=0)
    disp("This solution is incorrect")
else
    disp("This solution is correct")
end